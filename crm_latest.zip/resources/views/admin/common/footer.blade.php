 <!--**********************************
            Footer start
        ***********************************-->
 <div class="footer">
     <div class="copyright">
         <p>Copyright © Designed &amp; Developed by <a href="https://adzquare.com/" target="_blank">Adzquare by Makku Enterprises</a> 2025</p>
     </div>
 </div>
 <!--**********************************
            Footer end
        ***********************************-->
